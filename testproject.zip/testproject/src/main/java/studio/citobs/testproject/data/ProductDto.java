package studio.citobs.testproject.data;

public class ProductDto {
}
